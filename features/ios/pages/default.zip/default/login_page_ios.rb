require 'calabash-cucumber/operations'
require 'calabash-cucumber/calabash_steps'
require_relative ''

class LoginPage < BasePage

  def trait
    $g_query_txt+"marked:'#{@@login_page_text}'"
  end

  def await(opts={})
    wait_for_elements_exist([trait])
    self
  end

  #Read and Enter data from excel sheet
  def enter_credentials_from_excel(test_data)
  end


end