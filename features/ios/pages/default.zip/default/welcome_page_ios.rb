require 'calabash-cucumber/operations'
require 'calabash-cucumber/calabash_steps'
require_relative '../../../BasePages/welcome_page'

class WelcomePage < WelcomeBasePage

  def trait
    sleep(5)
    $g_query_txt+"marked:'#{@@welcome_page_text}'"
  end

  def navigate_to_login
    transition(:tap => @@welcome_page_ready_to_login, :page => LoginPage)
  end

  def click_login_text
    puts "waiting"
    sleep(5)
    click_on_text(@@welcome_page_login_text)
  end

  def await(opts={})
    wait_for_elements_exist([trait], :timeout => 5)
    self
  end

  def login_button_query
    $g_query_txt+"text:#{read_str('welcome_login_header')}"
  end


end